# json_tutorial
Tutorial de JSON en Youtube
https://youtu.be/lLsYjzpSDyA
